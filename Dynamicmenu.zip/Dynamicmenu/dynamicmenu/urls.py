"""dynamicmenu URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from dynamic_app import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('main', views.maninmenu, name='mainmenu'),
    path('submenu', views.submenu, name='submenu'),
    path('mainsave', views.mainsave, name='msave'),
    path('submenusave', views.subsave, name='submenusave'),
    path('role', views.userroles, name='role'),
    path('userroles_save', views.userroles_save, name='userroles_save'),
    path('user_role_menu', views.user_role_menu, name='user_role_menu'),
    path('user_role_menu_save', views.user_role_menu_save, name='user_role_menu_save'),
    path('user_role_menu_edit', views.user_role_menu_edit, name='user_role_menu_edit'),
    path('', views.dynamic_menu, name='dmenu'),
    path('login', views.login_page, name='login'),
    path('logout', views.logout_view, name='logout'),
]
