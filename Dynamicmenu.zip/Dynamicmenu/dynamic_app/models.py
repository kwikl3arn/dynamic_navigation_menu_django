from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class main_menu(models.Model):
    m_menu_id = models.AutoField(primary_key=True)
    m_menu_name = models.CharField(max_length=50)
    m_menu_link = models.CharField(max_length=100, blank=True, null=True)


class sub_menu(models.Model):
    s_menu_id = models.AutoField(primary_key=True)
    m_menu_id = models.IntegerField()
    s_menu_name = models.CharField(max_length=50)
    s_menu_link = models.CharField(max_length=100, blank=True, null=True)


class user_role(models.Model):
    Role_name = models.CharField(blank=True, null=True, max_length=50)
    role_status = models.BooleanField(default=True)


class main_menu_permission(models.Model):
    m_menu_id = models.IntegerField()
    m_menu_name = models.CharField(max_length=50, blank=True, null=True)
    m_menu_link = models.CharField(max_length=100, blank=True, null=True)
    role_id = models.IntegerField()
    user_id=models.CharField(max_length=50, blank=True, null=True)


class sub_menu_permission(models.Model):
    s_menu_id = models.IntegerField()
    m_menu_id = models.IntegerField()
    s_menu_name = models.CharField(max_length=50, blank=True, null=True)
    s_menu_link = models.CharField(max_length=100, blank=True, null=True)
    role_id = models.IntegerField()
    user_id = models.CharField(max_length=50, blank=True, null=True)
