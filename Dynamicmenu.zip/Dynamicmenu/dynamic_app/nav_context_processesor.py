from .models import main_menu_permission, sub_menu_permission
def nav_render(request):
    menu = main_menu_permission.objects.filter(user_id=request.user.id).order_by('m_menu_sortby')
    submenu = sub_menu_permission.objects.filter(user_id=request.user.id).order_by('s_menu_sortby')
    # print(request.user.id,request.user)
    return  {'menu1': menu, 'submenu1': submenu}