from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from dynamic_app.models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.conf import settings


# Create your views here.

# login validation view
def login_page(request):
    # print('--------------------------------------')
    # print('now in login_page')
    if request.user.is_authenticated:
        return redirect(settings.LOGIN_REDIRECT_URL)
    elif request.method == "POST":
        # print(request.POST)
        username = request.POST.get('InputEmail1')
        password = request.POST.get('InputPassword1')
        user = authenticate(request, username=username, password=password)
        if user is None:
            User = get_user_model()
            user_queryset = User.objects.all().filter(email__iexact=username)
            if user_queryset:
                username = user_queryset[0].username
                user = authenticate(username=username, password=password)
        if user is not None:
            request.session.set_expiry(14400)  # session expire in 4 hrs
            login(request, user)  # the user is now logged in
            # print('user loged in:', request.user.is_authenticated)
            # if user clicked something which is required login,
            # after login it will redirect to that page,what ever user clicked
            if 'next' in request.GET:
                return redirect(request.GET['next'])
            else:
                return redirect('dmenu')

        else:
            return render(request, 'login.html', context={'msg': 'Invalid User Name / Password'})
    else:

        return render(request, 'login.html', context={})

def menu_all_data(uid):
        menu = main_menu_permission.objects.filter(user_id=uid)
        submenu = sub_menu_permission.objects.filter(user_id=uid)
        menu_id=menu
        return [menu,submenu]

# logout view
@login_required
def logout_view(request):
    # print('--------------------------------------')
    # print('now in logout_view')
    logout(request)
    return redirect('login')


def maninmenu(request):
    mainmenu = main_menu.objects.all()
    menu,submenu =  menu_all_data(request.user.id)
    return render(request, 'menu.html', {'main_menu': mainmenu,'menu': menu, 'submenu': submenu})


def submenu(request):
    m_menu = main_menu.objects.all()
    s_submenu = sub_menu.objects.all()
    menu,submenu =  menu_all_data(request.user.id)
    return render(request, 'submenu.html', {'m_menu': m_menu, 's_submenu': s_submenu,'menu': menu, 'submenu': submenu})


def mainsave(request):
    if request.method == 'POST':
        mname = request.POST['menu_name']
        mlink = request.POST['mn_link']
        main_menu.objects.create(m_menu_name=mname, m_menu_link=mlink)
        # return HttpResponse("created")
        return redirect('mainmenu')
    else:
        return redirect('mainmenu')


def subsave(request):
    if request.method == 'POST':
        menuid = request.POST['parent']
        sname = request.POST['sub_menu_name']
        slink = request.POST['sub_menu_link']
        sub_menu.objects.create(m_menu_id=menuid, s_menu_name=sname, s_menu_link=slink)
        return redirect('submenu')
    else:
        return redirect('submenu')

@login_required()
def dynamic_menu(request):
    menu = main_menu_permission.objects.filter(user_id=request.user.id)
    submenu = sub_menu_permission.objects.filter(user_id=request.user.id)
    print(request.user.id,request.user)
    return render(request, 'dynamic_menu.html', {'menu': menu, 'submenu': submenu})


def userroles(request):
    usrrole = user_role.objects.all()
    menu,submenu =  menu_all_data(request.user.id)
    return render(request, 'user_role.html', {'usr_role': usrrole,'menu': menu, 'submenu': submenu})


def userroles_save(request):
    if request.method == 'POST':
        rolename = request.POST['Role_name']
        user_role.objects.create(Role_name=rolename)
        return redirect('role')
    else:
        return redirect('role')


def user_role_menu(request):
    r_menu = main_menu.objects.all()
    r_submenu = sub_menu.objects.all()
    r_usrrole = user_role.objects.all()
    user = User.objects.all()
    menu,submenu =  menu_all_data(request.user.id)
    return render(request, 'user_role_menu.html', {'r_menu': r_menu, 'r_submenu': r_submenu, 'r_usrrole': r_usrrole, 'user': user,'menu': menu, 'submenu': submenu})


def user_role_menu_save(request):
    if request.method == 'POST':
        rolename = request.POST['Role_name']
        username = request.POST['user_name']
        print(rolename)
        menu = request.POST.getlist('menu[]')
        main_menu_permission.objects.filter(user_id=username).delete()
        sub_menu_permission.objects.filter(user_id=username).delete()
        for m in menu:
            submenu = request.POST.getlist('submenu_{}[]'.format(m))
            menu = main_menu.objects.filter(m_menu_id=m)
            print('menu=', menu[0].m_menu_name)

            main_menu_permission.objects.create(m_menu_id=m, m_menu_name=menu[0].m_menu_name,
                                                m_menu_link=menu[0].m_menu_link, role_id=rolename, user_id=username)
            for sub in submenu:
                print('sub=', sub)
                subm = sub_menu.objects.filter(s_menu_id=sub)
                print('submenu=', subm[0].s_menu_name)
                sub_menu_permission.objects.create(s_menu_id=sub, m_menu_id=m, s_menu_name=subm[0].s_menu_name,
                                                   s_menu_link=subm[0].s_menu_link, role_id=rolename, user_id=username)
        return redirect('user_role_menu')
    else:
        pass
