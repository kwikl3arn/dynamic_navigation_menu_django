from .models import main_menu_permission, sub_menu_permission
def nav_render(request):
    menu = main_menu_permission.objects.filter(user_id=request.user.id)
    submenu = sub_menu_permission.objects.filter(user_id=request.user.id)
    print(request.user.id,request.user)
    return  {'menu1': menu, 'submenu1': submenu}